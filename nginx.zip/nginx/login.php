<?php
include "init.php";

echo $userObj->hash('password');
?>
