<?php
include "init.php";
echo $validate->myClass();
?>
